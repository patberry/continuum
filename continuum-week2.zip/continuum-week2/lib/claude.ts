// lib/claude.ts
// Claude API integration for Continuum
// Brand-aware prompt generation with learning

import Anthropic from '@anthropic-ai/sdk';
import { createClient } from '@supabase/supabase-js';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
});

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export interface BrandContext {
  brandId: string;
  brandName: string;
  brandDescription: string;
  guidelines: string[];
  learnedPatterns: LearnedPattern[];
  recentPrompts: RecentPrompt[];
}

export interface LearnedPattern {
  patternType: string;
  patternValue: string;
  confidence: number;
  timesUsed: number;
}

export interface RecentPrompt {
  promptText: string;
  userInput: string;
  feedback: 'great' | 'good' | 'bad' | null;
  platform: string;
}

export interface GenerationRequest {
  userInput: string;
  platform: 'veo3' | 'sora' | 'midjourney' | 'flux';
  outputType: 'video' | 'still';
  sessionId: string;
  brandId: string;
  userId: string;
}

export interface GenerationResult {
  success: boolean;
  promptText?: string;
  promptId?: string;
  platformRecommendation?: string;
  technicalNotes?: string;
  error?: string;
}

/**
 * Load full brand context for prompt generation
 */
async function loadBrandContext(brandId: string, userId: string): Promise<BrandContext | null> {
  // Get brand profile
  const { data: brand, error: brandError } = await supabase
    .from('brand_profiles')
    .select('*')
    .eq('brand_id', brandId)
    .eq('user_id', userId)
    .single();

  if (brandError || !brand) return null;

  // Get learned patterns (brand intelligence)
  const { data: patterns } = await supabase
    .from('brand_intelligence')
    .select('pattern_type, pattern_value, confidence_score, times_applied')
    .eq('brand_id', brandId)
    .order('confidence_score', { ascending: false })
    .limit(20);

  // Get recent prompts for context (last 10, with feedback)
  const { data: recentPrompts } = await supabase
    .from('prompts')
    .select('prompt_text, user_input, feedback_rating, platform')
    .eq('brand_id', brandId)
    .order('created_at', { ascending: false })
    .limit(10);

  return {
    brandId: brand.brand_id,
    brandName: brand.brand_name,
    brandDescription: brand.brand_description || '',
    guidelines: brand.guidelines || [],
    learnedPatterns: (patterns || []).map(p => ({
      patternType: p.pattern_type,
      patternValue: p.pattern_value,
      confidence: p.confidence_score,
      timesUsed: p.times_applied
    })),
    recentPrompts: (recentPrompts || []).map(p => ({
      promptText: p.prompt_text,
      userInput: p.user_input,
      feedback: p.feedback_rating,
      platform: p.platform
    }))
  };
}

/**
 * Build the system prompt for Claude
 */
function buildSystemPrompt(brandContext: BrandContext, platform: string, outputType: string): string {
  const platformSpecs = getPlatformSpecs(platform);

  let systemPrompt = `You are Continuum, a professional broadcast production AI. You generate ${outputType} prompts optimized for ${platform}.

## Your Core Methodology: Motion-First
For video prompts:
1. Lead with the primary motion/action
2. Add camera movement second
3. Layer in environmental details
4. End with technical specifications

## Brand Context: ${brandContext.brandName}
${brandContext.brandDescription}

## Platform: ${platform}
${platformSpecs}

`;

  // Add learned patterns
  if (brandContext.learnedPatterns.length > 0) {
    systemPrompt += `## Learned Brand Patterns (apply these):\n`;
    for (const pattern of brandContext.learnedPatterns.slice(0, 10)) {
      systemPrompt += `- ${pattern.patternType}: ${pattern.patternValue} (used ${pattern.timesUsed}x)\n`;
    }
    systemPrompt += '\n';
  }

  // Add context from successful recent prompts
  const successfulPrompts = brandContext.recentPrompts.filter(p => p.feedback === 'great' || p.feedback === 'good');
  if (successfulPrompts.length > 0) {
    systemPrompt += `## Recent Successful Prompts (reference style):\n`;
    for (const prompt of successfulPrompts.slice(0, 3)) {
      systemPrompt += `Input: "${prompt.userInput}"\nGenerated: "${prompt.promptText.slice(0, 200)}..."\n\n`;
    }
  }

  systemPrompt += `## Output Format
Return ONLY the prompt text, no explanations or markdown. The prompt should be immediately usable in ${platform}.

For video: Include motion verbs, camera movement, timing cues.
For stills: Include composition, lighting, mood, technical specs.

Quality bar: Broadcast/cinema grade, not social media.`;

  return systemPrompt;
}

/**
 * Get platform-specific guidance
 */
function getPlatformSpecs(platform: string): string {
  const specs: Record<string, string> = {
    veo3: `Veo 3 Optimization:
- Best for: Motion-critical shots, automotive, product demos
- Strength: 85%+ consistency for complex motion
- Format: Prose prompts work best (not JSON)
- Key: Lead with action verbs, be specific about motion direction
- Resolution: Up to 1080p, 8 seconds max`,

    sora: `Sora Optimization:
- Best for: Cinematic lighting, atmospheric shots
- Strength: Beautiful aesthetics, struggles with complex motion coordination
- Format: Detailed prose descriptions
- Key: Focus on mood, lighting, atmosphere over complex action
- Resolution: Up to 1080p, 20 seconds max`,

    midjourney: `Midjourney Optimization:
- Best for: Hero stills, product beauty shots
- Format: Use --ar for aspect ratio, --v 6.1 for latest
- Key: Cinematic lighting, professional photography terms
- Include: Camera lens, f-stop, lighting setup`,

    flux: `Flux Optimization:
- Best for: Photorealistic product shots
- Format: Detailed natural language
- Key: Technical photography terms, specific lighting
- Include: Camera angle, focal length, environment`
  };

  return specs[platform] || 'Standard prompt generation.';
}

/**
 * Generate a prompt using Claude
 */
export async function generatePrompt(request: GenerationRequest): Promise<GenerationResult> {
  // Load brand context
  const brandContext = await loadBrandContext(request.brandId, request.userId);
  if (!brandContext) {
    return { success: false, error: 'Brand not found or access denied' };
  }

  // Build system prompt with brand intelligence
  const systemPrompt = buildSystemPrompt(brandContext, request.platform, request.outputType);

  try {
    // Call Claude API
    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1024,
      system: systemPrompt,
      messages: [
        {
          role: 'user',
          content: `Generate a ${request.outputType} prompt for: ${request.userInput}`
        }
      ]
    });

    // Extract prompt text
    const promptText = message.content[0].type === 'text'
      ? message.content[0].text.trim()
      : '';

    if (!promptText) {
      return { success: false, error: 'Failed to generate prompt' };
    }

    // Store prompt in database
    const { data: savedPrompt, error: saveError } = await supabase
      .from('prompts')
      .insert({
        session_id: request.sessionId,
        brand_id: request.brandId,
        user_id: request.userId,
        prompt_text: promptText,
        user_input: request.userInput,
        platform: request.platform,
        output_type: request.outputType
      })
      .select('prompt_id')
      .single();

    if (saveError) {
      console.error('Failed to save prompt:', saveError);
      // Still return the prompt even if save fails
    }

    return {
      success: true,
      promptText,
      promptId: savedPrompt?.prompt_id,
      platformRecommendation: request.platform,
      technicalNotes: `Optimized for ${request.platform} ${request.outputType} generation`
    };

  } catch (error) {
    console.error('Claude API error:', error);
    return { success: false, error: 'AI generation failed. Please try again.' };
  }
}

/**
 * Store feedback and learn from it
 */
export async function storeFeedback(
  promptId: string,
  userId: string,
  rating: 'great' | 'good' | 'bad'
): Promise<boolean> {
  // Update prompt with feedback
  const { error } = await supabase
    .from('prompts')
    .update({ feedback_rating: rating })
    .eq('prompt_id', promptId)
    .eq('user_id', userId);

  if (error) return false;

  // If great rating, extract patterns for learning
  if (rating === 'great') {
    await learnFromPrompt(promptId);
  }

  return true;
}

/**
 * Extract patterns from successful prompts for brand intelligence
 */
async function learnFromPrompt(promptId: string): Promise<void> {
  const { data: prompt } = await supabase
    .from('prompts')
    .select('*')
    .eq('prompt_id', promptId)
    .single();

  if (!prompt) return;

  // Extract simple patterns (can be enhanced with Claude analysis later)
  const patterns: Array<{ type: string; value: string }> = [];

  // Camera angle detection
  const cameraAngles = ['low angle', 'high angle', 'eye level', '3/4 angle', 'aerial', 'tracking'];
  for (const angle of cameraAngles) {
    if (prompt.prompt_text.toLowerCase().includes(angle)) {
      patterns.push({ type: 'camera_angle', value: angle });
    }
  }

  // Lighting detection
  const lightingTypes = ['golden hour', 'blue hour', 'studio lighting', 'natural light', 'dramatic lighting'];
  for (const light of lightingTypes) {
    if (prompt.prompt_text.toLowerCase().includes(light)) {
      patterns.push({ type: 'lighting', value: light });
    }
  }

  // Store learned patterns
  for (const pattern of patterns) {
    // Check if pattern exists
    const { data: existing } = await supabase
      .from('brand_intelligence')
      .select('intelligence_id, times_applied, confidence_score')
      .eq('brand_id', prompt.brand_id)
      .eq('pattern_type', pattern.type)
      .eq('pattern_value', pattern.value)
      .single();

    if (existing) {
      // Increment usage count and boost confidence
      await supabase
        .from('brand_intelligence')
        .update({
          times_applied: existing.times_applied + 1,
          confidence_score: Math.min(1.0, existing.confidence_score + 0.1),
          updated_at: new Date().toISOString()
        })
        .eq('intelligence_id', existing.intelligence_id);
    } else {
      // Create new pattern
      await supabase
        .from('brand_intelligence')
        .insert({
          brand_id: prompt.brand_id,
          pattern_type: pattern.type,
          pattern_value: pattern.value,
          confidence_score: 0.5,
          times_applied: 1,
          source: 'user_feedback'
        });
    }
  }
}
